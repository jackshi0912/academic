Name: Huize Shi
edX username: hus006
edX email: hus006@ucsd.edu
code-grader url: https://lifan.s3.amazonaws.com/hw2_code/3b2b16f76cff8629372e0cb4d18cf0fd/20170217205127/index.html
image-grader url: https://lifan.s3.amazonaws.com/hw2/3b2b16f76cff8629372e0cb4d18cf0fd/20170217205053/index.html