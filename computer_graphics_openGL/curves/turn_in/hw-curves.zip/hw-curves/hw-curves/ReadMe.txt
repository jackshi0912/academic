Name: Huize Shi
Code-grader URL: 
http://52.42.39.203/cs167hw3/reports/hus0061488396764/hw3_report_hus0061488396764.html